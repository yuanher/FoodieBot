var express = require("express");
var bodyParser = require("body-parser");
var routes = require("./apiRouter");

var app = express();
var port = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use("/", routes);

// listens at the port
var listener = app.listen(process.env.PORT, process.env.IP, function() {
  console.log("starting the server");
  console.log("port is " + listener.address().port);
});

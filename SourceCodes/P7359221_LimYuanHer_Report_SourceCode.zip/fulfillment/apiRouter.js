var express = require("express");
var bodyParser = require("body-parser");
var admin = require("firebase-admin");
var { WebhookClient } = require("dialogflow-fulfillment");
var {
  Text,
  Card,
  Image,
  Suggestion,
  Payload
} = require("dialogflow-fulfillment");
var request = require("request");
var rp = require("request-promise-native");

process.env.DEBUG = "dialogflow:debug"; // enables lib debugging statements

const apiRouter = express.Router();

apiRouter.use(bodyParser.json());

var serviceAccount = require("./foodiebot-eswiyv-firebase-adminsdk-hpfxz-14ac5576ae.json");

var output_text = null;

//Firebase database connection
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://foodiebot-eswiyv.firebaseio.com"
});

// link and image URLs
const ImageUrl =
  "https://cdn.pixabay.com/photo/2016/05/26/14/11/chef-1417239_1280.png";
const RecipeImageUrl_Prefix = "https://spoonacular.com/recipeImages/";
const RecipeInfoUrl_Prefix = "https://spoonacular.com/";
const Url = "https://foodiebot-api.herokuapp.com/";
const ErrorImageUrl = "https://braziliex.com/img/erro1.png";
const ErrorImage = new Image(ErrorImageUrl);

// Bottom navigation menu for dialogflow response
function promptMenu(agent, prompt, msgSeparator) {
  if (msgSeparator == true) {
    agent.add("");
    agent.add("");
    agent.add("-".repeat(50));
  }

  agent.add(prompt);
  agent.add(new Suggestion("🍴 Get Meal Plan"));
  agent.add(new Suggestion("💁 Get Food Titbits"));
  agent.add(new Suggestion("🥘Get Food Nutrition"));
}

//webhook for Welcome intent
function welcome(agent) {
  agent.add("👋 Welcome! to FoodieBot! 👋");
  agent.add(
    new Card({
      title: "FoodieBot",
      imageUrl: ImageUrl,
      text: "Your wish is my command! 😱",
      buttonText: " Page",
      buttonUrl: Url
    })
  );
  promptMenu(agent, "What can I do for you today?", false);
}

//webhook for "foodnutrition" intent
function getFoodNutrition(agent) {
  const keyword = agent.parameters.keyword;

  var options = {
    uri:
      "https://api.spoonacular.com/recipes/guessNutrition?apiKey=d5f5d62cbdfe4500b69c50facb50d176&title=" +
      keyword,
    qs: {},
    headers: {
      "User-Agent": "Request-Promise"
    },
    json: true // Automatically parses the JSON string in the response
  };

  return rp(options).then(data => {
    agent.add("The Nutrition Information for " + keyword + " is:");

    var calories = data.calories.value;
    var carbs = data.calories.value;
    var fat = data.fat.value;
    var protein = data.protein.value;

    agent.add(
      "🍝 Calories:" +
        calories +
        ", 🥓 Fat: " +
        fat +
        ", 🍗 Protein: " +
        protein +
        ", 🍚 Carbs: " +
        carbs
    );
    promptMenu(agent, "What do you want to do next?", true);

    return Promise.resolve(agent);
  });
}

//webhook for "foodtitbits-start" intent
function getFoodTitBitChoice(agent) {
  agent.add(new Suggestion("Food Trivia"));
  agent.add(new Suggestion("Food Joke"));
}

//webhook for "foodtitbits-getTrivia" intent
function getFoodTrivia(agent) {
  var options = {
    uri:
      "https://api.spoonacular.com/food/trivia/random?apiKey=d5f5d62cbdfe4500b69c50facb50d176",
    qs: {},
    headers: {
      "User-Agent": "Request-Promise"
    },
    json: true // Automatically parses the JSON string in the response
  };

  return rp(options).then(data => {
    console.log("💁 " + data.text);
    agent.add("💁 " + data.text);
    promptMenu(agent, "What do you want to do next?", true);

    return Promise.resolve(agent);
  });
}

//webhook for "foodtitbits-getJoke" intent
function getFoodJoke(agent) {
  var options = {
    uri:
      "https://api.spoonacular.com/food/jokes/random?apiKey=d5f5d62cbdfe4500b69c50facb50d176",
    qs: {},
    headers: {
      "User-Agent": "Request-Promise"
    },
    json: true // Automatically parses the JSON string in the response
  };

  return rp(options).then(data => {
    console.log("😜 " + data.text);
    agent.add("😜 " + data.text);
    promptMenu(agent, "What do you want to do next?", true);

    return Promise.resolve(agent);
  });
}

//webhook for "mealplan-start" intent
function getMealPlanInput(agent) {
  const timeFrame = agent.parameters.TimeFrame;
  const targetCalories = agent.parameters.CaloricTarget;

  //Slot filling
  if (timeFrame == "") {
    agent.add("🗓️ Please enter TimeFrame (Day/Week)");
    agent.add(new Suggestion("Day"));
    agent.add(new Suggestion("Week"));
  } else if (targetCalories == "" || isNaN(targetCalories)) {
    agent.add("🍝 Please enter caloric target e.g. 2000");
  } else {
    agent.add("🥗 Wish to specify diet type?");
    agent.add(new Suggestion("Yes"));
    agent.add(new Suggestion("No"));
  }
}

//webhook for "mealplan-getDietTypeYES" intent
function getMealPlanInputDietTypeYes(agent) {
  var dietTypes = [
    "Gluten Free",
    "Ketogenic",
    "Vegetarian",
    "Lacto-Vegetarian",
    "Ovo-Vegetarian",
    "Vegan",
    "Pescetarian",
    "Paleo",
    "Primal",
    "Whole30"
  ];

  var diet = agent.parameters.DietType;

  if (diet == "") {
    agent.add("🥗 Please enter diet type");

    var arrayLength = dietTypes.length;

    for (var i = 0; i < arrayLength; i++) {
      agent.add(new Suggestion(dietTypes[i]));
    }
  } else {
    agent.add(new Suggestion("Next"));
  }
}

//webhook for "mealplan-getDietTypeNO" intent
function getMealPlanInputDietTypeNo(agent) {
  agent.add(new Suggestion("Next"));
}

//webhook for "mealplan-getExcludedIngredients" intent
function getMealPlan(agent) {
  var timeFrame = agent.parameters.TimeFrame;
  var targetCalories = agent.parameters.CaloricTarget;
  var diet = agent.parameters.DietType.toString();
  var exclude = agent.parameters.ExcludedIngredients.toString();

  exclude = exclude == "None" ? "" : exclude;
  diet = diet == "None" ? "" : diet;

  var get_url =
    "https://api.spoonacular.com/recipes/mealplans/generate?apiKey=d5f5d62cbdfe4500b69c50facb50d176&timeFrame=" +
    timeFrame +
    "&targetCalories=" +
    targetCalories +
    "&diet=" +
    diet +
    "&exclude=" +
    exclude;
    
  console.log(get_url);

  var options = {
    uri: get_url,
    qs: {},
    headers: {
      "User-Agent": "Request-Promise"
    },
    json: true // Automatically parses the JSON string in the response
  };

  var meal_titles = ["Breakfast", "Lunch", "Dinner"];
  return rp(options).then(data => {

    // Daily Meal plan
    if(timeFrame == "Day") {
      console.log(data.meals.length);
      var arrayLength = data.meals.length;
      for (var i = 0; i < arrayLength; i++) {
        console.log(data.meals[i].title);

        var meal_type = meal_titles[i];
        var meal_title = data.meals[i].title;
        admin
          .database()
          .ref("/log")
          .push({ Type: meal_type, Title: meal_title });

        agent.add(
          new Card({
            title: meal_titles[i],
            imageUrl: RecipeImageUrl_Prefix + data.meals[i].image,
            text: data.meals[i].title,
            buttonText: " Get details",
            buttonUrl: RecipeInfoUrl_Prefix + data.meals[i].image.split(".")[0]
          })
        );
      }
    // Weekly Meal plan
    }else if(timeFrame == "Week"){
      console.log(data.items.length);
      
      // create meals dictionary for 7 day meal plan
      var meals = {}; 
      for(var i = 1; i < 8; i++) {
        meals[i] = {};
      }

      // Add 7 day meal plan to meals dictionary
      var arrayLength = data.items.length;
      for(var i = 0; i < arrayLength; i++) {
        const obj = JSON.parse(data.items[i].value);
        var title = obj.title;
        var day = data.items[i].day;
        var slot = data.items[i].slot;
        meals[day][slot] = title;
      }
    
      // Day numeric to text mapping
      var dayMap = {
        1: "Monday",
        2: "Tuesday",
        3: "Wednesday",
        4: "Thursday",
        5: "Friday",
        6: "Saturday",
        7: "Sunday"
      };

      // Create Card reply based on meal plan
      for(var i = 1; i < 8; i++) {
        var bf = meals[i][1] + " [Breakfast]";
        var lunch = meals[i][2] + " [Lunch]";
        var dinner = meals[i][3] + " [Dinner]";
        var meal_details = bf + ", " + lunch + ", " + dinner;
        console.log(meal_details);
        agent.add(
          new Card({
            title: dayMap[i],
            imageUrl: "",
            text: meal_details,
            buttonText: "",
            buttonUrl: ""
          })
        );
      }
    }

    promptMenu(agent, "What do you want to do next?", true);

    return Promise.resolve(agent);
  });
}

// Web route
apiRouter
  .route("/")
  .get((req, res, next) => {
    console.log("root route");
    //res.send("<h1>FoodieBot DialogFlow Fulfillment API</h1>");
    res.sendFile("main.html", { root: __dirname });
  })

  .post((req, res, next) => {
    const agent = new WebhookClient({ request: req, response: res });

    let intentMap = new Map(); // Map functions to Dialogflow intent names
    intentMap.set("welcome", welcome);
    intentMap.set("foodnutrition", getFoodNutrition);
    intentMap.set("foodtitbits-start", getFoodTitBitChoice);
    intentMap.set("foodtitbits-getTrivia", getFoodTrivia);
    intentMap.set("foodtitbits-getJoke", getFoodJoke);
    intentMap.set("mealplan-start", getMealPlanInput);
    intentMap.set("mealplan-getDietTypeYES", getMealPlanInputDietTypeYes);
    intentMap.set("mealplan-getDietTypeNO", getMealPlanInputDietTypeNo);
    intentMap.set("mealplan-getExcludedIngredients", getMealPlan);

    agent.handleRequest(intentMap);
  })

  .put((req, res, next) => {
    res.statusCode = 403;
    res.end("PUT operation not supported on /equipment");
  })

  .delete((req, res, next) => {
    res.statusCode = 403;
    res.end("DELETE operation not supported on /");
  });

module.exports = apiRouter;
